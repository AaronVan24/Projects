/*
 * ErrorHandling.h
 *
 *  Created on: Nov 9, 2023
 *      Author: aaronvan
 */


#ifndef INC_ERRORHANDLING_H_
#define INC_ERRORHANDLING_H_

#include <stdbool.h>

void APPLICATION_ASSERT(bool);

#endif /* INC_ERRORHANDLING_H_ */
